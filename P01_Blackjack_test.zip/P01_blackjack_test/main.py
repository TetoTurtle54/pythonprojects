import pygame, random

"""
PERSONAL PROJECT 01: Make Blackjack in Pygame

FUNDAMENTALS OF BLACKJACK:
Player and Dealer play with a standard deck of 52 playing cards.
The goal for the player is to reach or get as close to the total of the cards in their hand adding up to 21 without going over.
(Suit doesn't really matter so it will be easier on me to code them without suits, but I might have to later.)

CARDS:
Numbered cards 2 - 10 are worth their face value.
There are 4 of every numbered card in the deck, so there are 36 numbered cards.
Aces are worth 1 or 11 and are interchangable based what benefits the player, there are 4 Aces in the deck.
Face cards are worth 10 points, there are 12 face cards in the deck.
36 numbered + 4 Aces + 12 face = 52 cards
(Unlike TwentyOne, I NEED to code a proper deck this time.)

IDEAS FOR CODING A STANDARD DECK:



GAMEPLAY:
At the start of the game, the player places their bet, and the player and the dealer both recieve 2 cards.
The first card the dealer draws is hidden from the player. This is known as the hole card, and is revealed at the end of the round.
(If the dealer's 2nd card is an Ace, they must immediately check the hole card for a Blackjack. If a Blackjack is present, push.)

Player Actions:

HIT - Draw another card.
STAND - Keep your current hand.
DOUBLE DOWN - Double your bet and HIT for the last time before STANDing.
SPLIT - [not implementing right now]
FORFEIT - Fold and collect half of your bet. (If played bet is 1, collect no bet.)

Dealer Actions:

Once the player STANDs, the dealer will HIT until the total of their cards reaches at least 17.


GAME OUTCOMES:

2:1 Payout (Pays 2:1, so if I bet 200, I get back 400. My bet times 2.)
3:2 Payout (Pays 3:1, so if I bet 200, I get back 500. My bet plus my bet times (3/2).)

Player Wins:
If the player's hand is closer to 21 than the Dealer, the player wins a payout of 2:1.
If the player's hand is 21, they Blackjack, and win a payout of 3:2.
If the dealer busts, the player wins a payout of 2:1.

Player Loses:
If the player's hand is farther from 21 than the Dealer, they lose their bet.
If the player busts, they lose their bet.
If the player FORFEITs, they recieve half of their bet.

Player Pushes:
If the player and Dealer tie, they push and the player recieves their bet back.
If the Dealer immediately Blackjacks, they push and the player recieves their bet back.

"""




# init pygame
pygame.init()

# create a display surface
WINDOW_WIDTH = 1280
WINDOW_HEIGHT = 720
display_surface = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Blackjack!")

# set FPS and make a clock
FPS = 60
clock = pygame.time.Clock()

# variables
# CONSTANTS



# variables





# load fonts



# load game text



# load music and sounds



# load images




# CARD STUFF AHEAD
# create the deck to choose from


class CardNG:
    """This class is for cards that aren't graphical (NG - Non-Graphical)"""
    def __init__(self, suit, rank):
        self.suit = suit
        self.rank = rank
    
    def tellRank(self):
        return f"{self.rank} of {self.suit}"

suits = ["spades","diamonds","hearts","clubs"] # establish suits
deck = [] # create deck

# make the deck
for suit in suits:
    for i in range(1): # lol
        deck.append(CardNG(suit, "ace"))
        deck.append(CardNG(suit, "king"))
        deck.append(CardNG(suit, "queen"))
        deck.append(CardNG(suit, "jack"))
        for j in range(10,1,-1):
            deck.append(CardNG(suit, j))

"""
for card in deck:
    print(card.tellRank()) # say every card in the deck
print(len(deck)) # print the size of the deck
"""

# TESTING

# create graphical card class
class Card(pygame.sprite.Sprite):
    """This is a class for cards that are graphical."""
    def __init__(self, rank, suit, x, y):
        super().__init__()
        self.image = pygame.transform.scale_by(pygame.image.load(f"cards/{rank}_of_{suit}.png"), 0.2)
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

# create card class group
card_group = pygame.sprite.Group()


# Draw a hand of 8 cards using cards from the deck
x_pos = 100
hand = []
for i in range(8):
    card_drawn = random.choice(deck)
    deck.remove(card_drawn)
    hand.append(card_drawn)
for card in hand:
    x_pos += 120
    print(card.tellRank()) # say all of the cards
    current_card = Card(card.rank, card.suit, x_pos, 300)
    card_group.add(current_card)




# main game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    

    # draw the background
    display_surface.fill((38, 182, 128))

    # draw card group to display surface
    card_group.draw(display_surface)



    # update the display and tick the clock
    pygame.display.update()
    clock.tick(FPS)



# quit pygame
pygame.quit()