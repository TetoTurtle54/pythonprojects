from PyDictionary import *
from wonderwords import RandomWord
import colorama
from colorama import Fore, Back, Style


dictionary = PyDictionary()

r = RandomWord()
random_word = r.word(word_min_length=5, word_max_length=5)

"""
def check_word(word):
    dictionary = PyDictionary()
    meaning = dictionary.meaning(word)
    print(meaning)
    if meaning:
        print(f"'{word}' exists in the dictionary.")
    else:
        print(f"'{word}' does not exist in the dictionary.")

check_word("indentation")
print(dictionary.meaning("indent"))
check_word("djkadaskldjal")
print(random_word)
"""

print("Welcome to terminordle! This is a scuffed")
print("version of Wordle ran in the Python terminal.")
print()
"""
print("N = Letter not in word")
print("Y = Letter not in correct place and in word")
print("G = Letter in correct place and in word")
"""

def get_guess():
    return input(Fore.RESET + "Guess a 5 letter, lowercase word: ")

def parse_guess(word):

    splitword = list(word)
    for i in range(len(splitword)):
        if splitword[i] in random_word:
            if splitword[i] == random_word[i]:
                status[i] = "G"
            else:
                status[i] = "Y"
        else:
            status[i] = "N"
    
    return status

            


status = ["N","N","N","N","N"]
count = 10
guess = get_guess()
while count > 0:
    if not guess.islower():
        print("Your guess must consist of lowercase letters!")
        guess = get_guess()
        count -= 1
        continue
    elif len(guess) != 5:
        print("Your guess must be exactly five characters!")
        guess = get_guess()
        continue
    
    statusnew = parse_guess(guess)
    if statusnew == ["G", "G", "G", "G", "G"]:
        break
    guessstring = ""
    for i in range(len(statusnew)):

        if statusnew[i] == "N":
            guessstring += Fore.RESET + guess[i] + " "
        elif statusnew[i] == "Y":
            guessstring += Fore.YELLOW + guess[i] + " "
        else:
            guessstring += Fore.GREEN + guess[i] + " "
    print(guessstring)
    guess = get_guess()
    continue

    """
    if guess in secret_word:
        print("That letter is in the secret word!")
        guess = get_guess()
        count -= 1
    else:
        print("That letter is not in the secret word!")
        guess = get_guess()
        count -= 1
    """

print("You win! The word was: " + random_word)